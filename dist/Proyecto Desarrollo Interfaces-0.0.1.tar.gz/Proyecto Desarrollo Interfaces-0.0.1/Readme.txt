Manual
******
* El funcionamiento consta de un menu con 4 opciones:
    * Gestión de clientes permite añadir nuevos clientes, modificarlos a traves de un comboBox seleccionando su dni
      y eliminarlos.
    * Gestión de productos en la que podemos asignar productos a los diferentes clientes clientes.
    * Pedidos en el que podemos listar clientes y sus productos asignados mediante Treeview
      y crear factura para el cliente o generar una lista de todos los clientes.
    * Salir permite cerrar el programa.

* Además en cualquier momento podemos cerrar el programa dandole a la X o volver al menu con el boton volver
